﻿cd C:\#INVENTARIO_UOLDIVEO\
.\CRIAR_TEMP.ps1 -DirectoryToCreate C:\Temp


echo    "***************************************************************************************************" > c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo    "***                                                                                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo    "***                              INVENTARIO SIMPLIFICADO MICROSOFT                              ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo    "***                                       PRÉ-REQUISITOS                                        ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo    "***                                                                                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo    "***************************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt



echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                          INFORMAÇÕES DO SISTEMA                         ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

systeminfo >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "SERIAL NUMBER"  >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "==============" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
wmic bios get serialnumber >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
 

echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                          INFORMAÇÕES DOS DISCOS                         ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

get-psdrive -psprovider filesystem >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                           CONFIGURAÇÕES DE IPS                          ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

ipconfig /all >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt




echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                                ROTAS                                    ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

route print >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt



echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                            USUARIOS LOCAIS                              ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

net user >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                             GRUPOS LOCAIS                               ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

net localgroup >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                           TODOS OS SERVIÇOS                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

Get-Service >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.TXT


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                     TODOS OS SOFTWARES INSTALADOS                       ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion | Sort-Object -Property DisplayName -Unique | Format-Table -AutoSize >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                     VERIFICAÇÃO DO ANTI VÍRUS                           ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt


echo   "VERSÃO"  >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo  "========" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
reg query "hklm\software\symantec\symantec endpoint protection\currentversion" /t REG_sz |findstr -i "tname tversion"  >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "----------------------------------------------------" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

echo  "DATA DA ÚLTIMA DEFINIÇÃO" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "==========================" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
reg query "hklm\software\symantec\symantec endpoint protection\currentversion\SharedDefs" |findstr DEF >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt


echo "**************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt
echo "***                 TODOS OS KBS INSTALADOS DETALHADAMENTE                         ***" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt 
echo "**************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

Get-HotFix >> C:\TEMP\INVENTARIO_MICROSOFT_PRE-REQ.txt

cd C:\#INVENTARIO_UOLDIVEO\
.\RENAME_PREREQ.BAT

echo "VERIFICAR SE O ARQUIVO INVENTARIO_MICROSOFT_PRE-REQ.txt FOI CRIADO NA PASTA C:\TEMP"
echo "CASO POSITIVO, COPIE ELE PARA SUA MÁQUINA E RENOMEIE ELE COM O NOME DO SERVIDOR," 
echo "COLOCANDO NO FINAL _NOMEDOSERVIDOR.txt,ANEXE O ARQUIVO NA SUA TAREFA DE EXECUÇAÕ."


start c:\temp