﻿echo    "***************************************************************************************************" > c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo    "***                                                                                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo    "***                              INVENTARIO SIMPLIFICADO MICROSOFT                              ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo    "***                                  IMPLANTAÇÃO e VALIDAÇÃO                                    ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo    "***                                                                                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo    "***************************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt



echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                          INFORMAÇÕES DO SISTEMA                         ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

systeminfo >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "SERIAL NUMBER"  >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "==============" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
wmic bios get serialnumber >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
 

echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                          INFORMAÇÕES DOS DISCOS                         ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

get-psdrive -psprovider filesystem >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                           CONFIGURAÇÕES DE IPS                          ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

ipconfig /all >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt




echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                                ROTAS                                    ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

route print >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt



echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                            USUARIOS LOCAIS                              ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

net user >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                             GRUPOS LOCAIS                               ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

net localgroup >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                           TODOS OS SERVIÇOS                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

Get-Service >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.TXT


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                     TODOS OS SOFTWARES INSTALADOS                       ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion | Sort-Object -Property DisplayName -Unique | Format-Table -AutoSize >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt


echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                     VERIFICAÇÃO DO ANTI VÍRUS                           ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt 
echo "*******************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt


echo   "VERSÃO"  >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo  "========" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
reg query "hklm\software\symantec\symantec endpoint protection\currentversion" /t REG_sz |findstr -i "tname tversion"  >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "----------------------------------------------------" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

echo  "DATA DA ÚLTIMA DEFINIÇÃO" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "==========================" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
reg query "hklm\software\symantec\symantec endpoint protection\currentversion\SharedDefs" |findstr DEF >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt


echo "**************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "***                 TODOS OS KBS INSTALADOS DETALHADAMENTE                         ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt
echo "**************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt

Get-HotFix >> C:\TEMP\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt


echo    "***************************************************************************************************" > c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "***                                                                                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "***                              INVENTARIO SIMPLIFICADO MICROSOFT                              ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "***                                  COMPARAÇÃO E VALIDAÇÃO DAS                                 ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "***                                    ALTERAÇÕES REALIZADAS                                    ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "***                                                                                             ***" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "***************************************************************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt

Compare-Object -ReferenceObject $(Get-Content C:\Temp\INVENTARIO_MICROSOFT_PRE-REQ.txt) -DifferenceObject $(Get-Content C:\Temp\INVENTARIO_MICROSOFT_VALIDAÇÃO.txt) >> C:\Temp\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt


echo    "*******************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*                      OBSERVAÇÃO                     *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*                                                     *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*              Available Physical Memory              *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*              Virtual Memory: Available:             *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*              Virtual Memory: In Use:                *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*                   Lease Expires                     *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*           Alteraçao no Disco C Disponível           *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*                                                     *" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*SÃO ALTERAÇÕES QUE OCORRE EM REAL-TIME, NÃO SE APLICA*" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt
echo    "*******************************************************" >> c:\TEMP\INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt

echo "ARQUIVO ESTA SENDO RENOMEADO"
echo "DE:INVENTARIO_MICROSOFT_VALIDACAO_FINAL_DAS_ALTERACOES_REALIZADAS_NO_SERVIDOR.txt"
echo "PARA:INVENTARIO_MICROSOFT_ALTERACOES_REALIZADAS_NOME DO SERVIDOR_DATA_HORÁRIO"

cd C:\#INVENTARIO_UOLDIVEO\
.\RENAME.BAT

start c:\temp